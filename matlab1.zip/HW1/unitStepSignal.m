function res = impulseSignal(n0 , n)
  res = n >= n0;
endfunction